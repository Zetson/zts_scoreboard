local plist = false
local prevframes, prevtime, curtime, curframes, fps = 0, 0, 0, 0, 0
local playtime = 0
local playtimemin = 0
local playtimehr = 0
local playtimetotal = 0

Citizen.CreateThread(function()
    while not NetworkIsPlayerActive(PlayerId()) or not NetworkIsSessionStarted() do
        Citizen.Wait(250)
        prevframes = GetFrameCount()
        prevtime = GetGameTimer()
    end

    while true do
        Citizen.Wait(10)
        curtime = GetGameTimer()
        curframes = GetFrameCount()

        if (curtime - prevtime) > 1000 then
            fps = (curframes - prevframes) - 1              
            prevtime = curtime
            prevframes = curframes
        end
	end
end)

Citizen.CreateThread(function()
	while true do
		if IsControlJustPressed(1, 323) then--X
            if plist ~= true then
                plist = true
                sleep = 1000
                SetNuiFocus(plist, plist)
			    TriggerServerEvent("SWTList:Open",plist)
            else
                plist = false
                SetNuiFocus(plist, plist)
			    TriggerServerEvent("SWTList:Open",plist)
                
            end
		end
    Citizen.Wait(1)
	end
end)


Citizen.CreateThread(function()
    while true do
        Citizen.Wait(1000)
        playtime = playtime + 1
        if playtime >= 60 then
            playtime = 0
            playtimemin = playtimemin + 1
            if playtimemin >= 60 then 
                playtimemin = 0
                playtimehr = playtimehr + 1
            end
        end  
    end
end)



RegisterNetEvent('UISender')
AddEventHandler('UISender', function(plist, id, name,job,level,srctmp)
	SendNUIMessage({
		type = "OpenScoreboard",
        plist = plist,
		id = id, 
        nume = name,
		fps = fps,
        job = job,
        level = level,
        srctmp = srctmp
	})
end)

RegisterNetEvent('timecheck')
AddEventHandler('timecheck', function(iduri)
    local jucat = playtimehr.."ore ".. playtimemin .."min "..playtime.."s"
    local idss = iduri 
    TriggerServerEvent('SWTList:cb', jucat, idss)

end)


RegisterNUICallback('cbb', function(status)
    plist = false
    SetNuiFocus(false, false)
end)

RegisterCommand('of', function()
    SetNuiFocus(false, false)

end, false)

-- function dump(o)
--     if type(o) == 'table' then
--        local s = '{ '
--        for k,v in pairs(o) do
--           if type(k) ~= 'number' then k = '"'..k..'"' end
--           s = s .. '['..k..'] = ' .. dump(v) .. ','
--        end
--        return s .. '} '
--     else
--        return tostring(o)
--     end
--  end
