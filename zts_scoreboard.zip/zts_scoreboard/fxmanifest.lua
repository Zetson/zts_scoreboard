fx_version 'cerulean'
game 'gta5'

author 'Zetsonel'
description 'Playerlist made for Legacy Roleplay'
version '1.0.0'
dependency "vrp"

ui_page 'index.html'

files{
    'js/*',
    'css/*',
    'fonts/*',
    'bg.png',
    'favicon.ico',
    'index.html'
}

client_scripts {
    "lib/Tunnel.lua",
    "lib/Proxy.lua",
    "client.lua"
}

server_scripts {
    '@vrp/lib/utils.lua',
    '@vrp/lib/Tools.lua',
    "server.lua"

}

