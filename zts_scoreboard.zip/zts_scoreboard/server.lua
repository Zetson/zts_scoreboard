local Tunnel = module("vrp", "lib/Tunnel")
local Proxy = module("vrp", "lib/Proxy")

vRP = Proxy.getInterface("vRP")
vRPclient = Tunnel.getInterface("vRP","zts_scoreboard")

RegisterServerEvent('SWTList:Open')
AddEventHandler('SWTList:Open',function(plist)
   if plist then
    --  local src = source
      local iduri = {}
      local users = vRP.getUsers({})
      for userID, user in pairs(users) do
         table.insert(iduri,user)
      end

      for user_id,surce in pairs(users) do
         TriggerClientEvent('timecheck',surce,iduri)
      end
   else 
      TriggerClientEvent("UISender", source , plist, user_id, nume, job, level,srctmp)
   end
end)

RegisterServerEvent('SWTList:cb')
AddEventHandler('SWTList:cb',function(timp,iduri)
   local src = source
   local job = nil
   local nume
   local tabla = iduri

   for user_id in pairs(tabla) do
      local level = vRP.getUserLevel({user_id})
      local srctmp = timp
      vRP.getUserIdentity({user_id, function(identity)
         if identity then
            nume = identity.name.." "..identity.firstname
            --exemplu job, se trec grupurile, nu permisiile
            if vRP.hasGroup({user_id,"Miner"}) then
               job = 'Miner'
            elseif vRP.hasGroup({user_id,"Politist"}) then
               job = "Politist"
            elseif vRP.hasGroup({user_id,"SIAS"}) then
               job = "SIAS"
            else
               job = "Somer"
            end

            TriggerClientEvent("UISender", src , true, user_id, nume, job, level,srctmp)
         end
      end})
   end
end)

-- function dump(o)
--    if type(o) == 'table' then
--       local s = '{ '
--       for k,v in pairs(o) do
--          if type(k) ~= 'number' then k = '"'..k..'"' end
--          s = s .. '['..k..'] = ' .. dump(v) .. ','
--       end
--       return s .. '} '
--    else
--       return tostring(o)
--    end
-- end
